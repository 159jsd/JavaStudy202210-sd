package j04_연산자;

public class Operation4 {
    public static void main(String[] args) {
        int num = 10;

        num += 3;

        System.out.println(num);



    }
}
