package j06_조건;

public class Condition1 {
    public static void main(String[] args) {

        int num = 0;

        if(num > 0 || num == 0) {
            System.out.println("num은 0이거나 양수 입니다.");
        }
        else {
            System.out.println("num은 음수입니다.");
        }


    }
}
